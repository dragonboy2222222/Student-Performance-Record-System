package StudentSystem2;

public interface Report {
    void generate() throws Exception;
}
