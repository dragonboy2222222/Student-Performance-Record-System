package StudentSystem2;


import com.opencsv.exceptions.CsvException;

import java.io.IOException;
import java.util.LinkedList;

/**
 * Update student information by student ID
 */
public class UpdateStudent extends StudentOperationTemplate {
    private final DataValidation userValidation = new DataValidation();
    private final Studentdatawrite writeToCSV = new Studentdatawrite();
    private final CheckData searchStudentId = new CheckData();

    @Override
    protected void execute() throws IOException, CsvException {
        int id = userValidation.getId();
        int index = searchStudentId.searchId(students, id);

        while (index < 0) {
            System.err.println("'" + id + "' doesn't exist.");
            id = userValidation.getId();
            index = searchStudentId.searchId(students, id);
        }

        String name = userValidation.getName();
        int age = userValidation.getAge();
        boolean gender = userValidation.getGenderAsBoolean();
        double studyTime = userValidation.getStudyTime();
        int absences = userValidation.getAbsences();
        boolean tutoring = userValidation.getBooleanInput("Tutoring");
        boolean extracurriculum = userValidation.getBooleanInput("Extracurriculum");
        boolean sports = userValidation.getBooleanInput("Sports");
        boolean music = userValidation.getBooleanInput("Music");
        boolean volunteering = userValidation.getBooleanInput("Volunteering");
        double GPA = userValidation.calculateGPA(
                studyTime, absences, tutoring,
                extracurriculum, sports, music, volunteering
        );

        Student updatedStudent = new Student(
                id, name, age, gender, studyTime, absences,
                tutoring, extracurriculum, sports, music, volunteering, GPA
        );

        students.set(index, updatedStudent);
        writeToCSV.writeToFile(students, "data/Student dataset.csv");

        System.out.println("\n✅ Student Information Successfully Updated!");
    }
}
