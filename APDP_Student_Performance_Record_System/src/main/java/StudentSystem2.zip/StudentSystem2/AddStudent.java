package StudentSystem2;

import java.io.IOException;

/**
 * Add new student information into "students" dataset
 */
public class AddStudent extends StudentOperationTemplate {
    private final DataValidation userValidation = new DataValidation();
    private final Studentdatawrite dataWrite = new Studentdatawrite();
    private final CheckData searchStudentId = new CheckData();

    @Override
    protected void execute() throws IOException {
        int id = userValidation.getId();

        while (searchStudentId.searchId(students, id) >= 0) {
            System.out.println("ID '" + id + "' already exists.");
            id = userValidation.getId();
        }

        String name = userValidation.getName();
        int age = userValidation.getAge();
        boolean gender = userValidation.getGenderAsBoolean();
        double studyTime = userValidation.getStudyTime();
        int absences = userValidation.getAbsences();
        boolean tutoring = userValidation.getBooleanInput("Tutoring");
        boolean extracurriculum = userValidation.getBooleanInput("Extracurriculum");
        boolean sports = userValidation.getBooleanInput("Sports");
        boolean music = userValidation.getBooleanInput("Music");
        boolean volunteering = userValidation.getBooleanInput("Volunteering");
        double GPA = userValidation.calculateGPA(
                studyTime, absences, tutoring,
                extracurriculum, sports, music, volunteering
        );

        // Add to list
        students.add(new Student(id, name, age, gender, studyTime, absences,
                tutoring, extracurriculum, sports, music, volunteering, GPA));

        // Save to file
        dataWrite.writeToFile(students, "data/student dataset.csv");

        System.out.println("\n✅ Student Information Successfully Added!");
        System.out.println("📊 Updated Student Dataset Size: " + students.size());
    }
}
